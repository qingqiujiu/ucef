# UCEF v0.9 Data Model

UCEF separates reusable behavior from Scenario-specific execution.

## Reusable layer

- `behavior_fragments`: semantically complete behavior contracts.
- `fragment_revisions`: immutable history of Fragment changes.
- `evidence`: source/config/test/runtime observations.

## Scenario layer

- `scenarios`: business operation plus project/environment/config/request constraints.
- `trace_stages`: ordered reader-facing execution stages; may reference Fragments.
- `route_decisions`: definitions and current Scenario outcomes.
- `field_lineage_steps`: ordered transformations grouped by canonical field.
- `persistence_effects`: store operations and column/value provenance.
- `external_interactions`: request/response provenance and business effect.
- `gaps`: explicit missing knowledge and repair targets.

## Identity and reuse

Fragment lookup uses `logical_key` plus repository, code hash, binding hash, and applicability. Scenario stages reference Fragments but retain current inputs, route outcomes, outputs, and handoffs.

## Versioning

Changed payloads create immutable entity revisions before updating the current row. Status/evidence upgrades update the current entity and remain auditable. Code/config changes may mark a Fragment stale without deleting its historical uses.

