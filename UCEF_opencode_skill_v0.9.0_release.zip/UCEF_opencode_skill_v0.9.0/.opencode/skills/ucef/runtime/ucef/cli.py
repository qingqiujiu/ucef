from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

from .audit import audit_scenario
from .compare import compare_scenarios
from .context import ContextBuilder
from .core import load_json, write_json
from .site import DossierSiteBuilder
from .store import FactStore
from .validator import IngestionValidator


def runtime_root() -> Path:
    return Path(__file__).resolve().parents[1]


def project_root() -> Path:
    return Path.cwd()


def load_config(path: str | Path) -> dict[str, Any]:
    return load_json(path)


def resolve_project_path(value: str | Path) -> Path:
    path = Path(value)
    return path if path.is_absolute() else project_root() / path


def make_store(config: dict[str, Any]) -> FactStore:
    db_path = (config.get("database") or {}).get("path", ".ucef/ucef.db")
    return FactStore(resolve_project_path(db_path))


def emit(value: Any) -> None:
    print(json.dumps(value, ensure_ascii=False, indent=2))


def cmd_doctor(args: argparse.Namespace) -> int:
    issues = []
    for path in (
        runtime_root() / "UCEF_RULES.md",
        runtime_root() / "schema.json",
        runtime_root().parent / "references" / "READER_CONTRACT.md",
    ):
        if not path.exists():
            issues.append(f"Missing: {path}")
    try:
        config = load_config(args.config)
        store = make_store(config)
        store.close()
    except Exception as exc:
        issues.append(f"Runtime initialization failed: {type(exc).__name__}: {exc}")
    result = {"status": "OK" if not issues else "WARN", "issues": issues, "python": sys.version.split()[0], "external_dependencies": []}
    emit(result)
    return 0 if not issues else 1


def cmd_init(args: argparse.Namespace) -> int:
    config = load_config(args.config)
    store = make_store(config)
    store.close()
    emit({"status": "initialized", "workspace": str(project_root() / ".ucef")})
    return 0


def cmd_ingest(args: argparse.Namespace) -> int:
    config = load_config(args.config)
    store = make_store(config)
    try:
        data = load_json(args.file)
        report = IngestionValidator(store).ingest(data, args.scenario, args.work_unit)
        scenario_id = report.get("scenario_id")
        if scenario_id and store.has("scenarios", scenario_id):
            report["audit"] = audit_scenario(store, scenario_id, persist=True)
        site_cfg = config.get("site") or {}
        if site_cfg.get("auto_update", True):
            report["site"] = DossierSiteBuilder(store, config, project_root()).build()
        emit(report)
        return 1 if report["errors"] else 0
    finally:
        store.close()


def cmd_audit(args: argparse.Namespace) -> int:
    config = load_config(args.config)
    store = make_store(config)
    try:
        report = audit_scenario(store, args.scenario, persist=args.persist)
        emit(report)
        return 0 if report["readability_status"] == "READABLE_COMPLETE" else 2
    finally:
        store.close()


def cmd_reuse(args: argparse.Namespace) -> int:
    config = load_config(args.config)
    store = make_store(config)
    try:
        results = store.find_fragments(args.logical_key, args.repository, args.code_hash, args.binding_hash)
        emit({"logical_key": args.logical_key, "result": results or [{"reuse": "MISS"}]})
        return 0
    finally:
        store.close()


def cmd_context(args: argparse.Namespace) -> int:
    config = load_config(args.config)
    store = make_store(config)
    try:
        scenario = load_json(args.scenario)
        work_unit = load_json(args.work_unit)
        text = ContextBuilder(runtime_root(), store, config).build(scenario, work_unit)
        if args.output:
            target = Path(args.output)
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(text, encoding="utf-8")
            print(target)
        else:
            print(text)
        return 0
    finally:
        store.close()


def cmd_query(args: argparse.Namespace) -> int:
    config = load_config(args.config)
    store = make_store(config)
    try:
        if args.collection == "dossier":
            if not args.scenario:
                raise ValueError("--scenario is required for dossier")
            result = store.scenario_dossier(args.scenario)
        else:
            result = store.list_collection(args.collection, args.scenario)
        emit(result)
        return 0
    finally:
        store.close()


def cmd_compare(args: argparse.Namespace) -> int:
    config = load_config(args.config)
    store = make_store(config)
    try:
        result = compare_scenarios(store, args.left, args.right)
        if args.output:
            write_json(args.output, result)
        else:
            emit(result)
        return 0
    finally:
        store.close()


def cmd_site(args: argparse.Namespace) -> int:
    config = load_config(args.config)
    store = make_store(config)
    try:
        result = DossierSiteBuilder(store, config, project_root()).build()
        emit(result)
        return 0
    finally:
        store.close()


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="ucef", description="UCEF business execution dossier runtime")
    parser.add_argument("--config", default=".ucef/config.json")
    sub = parser.add_subparsers(dest="command", required=True)

    command = sub.add_parser("doctor")
    command.set_defaults(func=cmd_doctor)
    command = sub.add_parser("init")
    command.set_defaults(func=cmd_init)

    command = sub.add_parser("ingest")
    command.add_argument("--file", required=True)
    command.add_argument("--scenario")
    command.add_argument("--work-unit")
    command.set_defaults(func=cmd_ingest)

    command = sub.add_parser("audit")
    command.add_argument("--scenario", required=True)
    command.add_argument("--persist", action="store_true")
    command.set_defaults(func=cmd_audit)

    command = sub.add_parser("reuse")
    command.add_argument("--logical-key", required=True)
    command.add_argument("--repository")
    command.add_argument("--code-hash")
    command.add_argument("--binding-hash")
    command.set_defaults(func=cmd_reuse)

    command = sub.add_parser("build-context")
    command.add_argument("--scenario", required=True)
    command.add_argument("--work-unit", required=True)
    command.add_argument("--output")
    command.set_defaults(func=cmd_context)

    command = sub.add_parser("query")
    command.add_argument("--collection", required=True, choices=[
        "dossier", "scenarios", "fragments", "trace_stages", "route_decisions",
        "field_lineage_steps", "persistence_effects", "external_interactions", "gaps", "work_units",
    ])
    command.add_argument("--scenario")
    command.set_defaults(func=cmd_query)

    command = sub.add_parser("compare")
    command.add_argument("--left", required=True)
    command.add_argument("--right", required=True)
    command.add_argument("--output")
    command.set_defaults(func=cmd_compare)

    command = sub.add_parser("site")
    command.set_defaults(func=cmd_site)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        return int(args.func(args) or 0)
    except (KeyError, ValueError, FileNotFoundError, json.JSONDecodeError) as exc:
        emit({"status": "ERROR", "error": f"{type(exc).__name__}: {exc}"})
        return 2

