#!/usr/bin/env python3
from pathlib import Path
import shutil
import sys

SKILL_ROOT = Path(__file__).resolve().parents[1]
TEMPLATES = SKILL_ROOT / "templates"
PROJECT_ROOT = Path.cwd()
WORKSPACE = PROJECT_ROOT / ".ucef"

for directory in (
    WORKSPACE,
    WORKSPACE / "scenarios",
    WORKSPACE / "work_units" / "pending",
    WORKSPACE / "work_units" / "completed",
    WORKSPACE / "contexts",
    WORKSPACE / "runs",
    WORKSPACE / "site",
):
    directory.mkdir(parents=True, exist_ok=True)

copies = (
    (TEMPLATES / "config.json", WORKSPACE / "config.json"),
    (TEMPLATES / "scenario.json", WORKSPACE / "scenarios" / "scenario.example.json"),
    (TEMPLATES / "work_unit.json", WORKSPACE / "work_units" / "work_unit.example.json"),
)
created, kept = [], []
for source, target in copies:
    if target.exists():
        kept.append(str(target))
    else:
        shutil.copy2(source, target)
        created.append(str(target))

sys.path.insert(0, str(SKILL_ROOT / "runtime"))
from ucef.cli import main

result = main(["--config", str(WORKSPACE / "config.json"), "init"])
print("UCEF workspace:", WORKSPACE)
for path in created:
    print("  +", path)
for path in kept:
    print("  =", path)
raise SystemExit(result)
