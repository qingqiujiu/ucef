## UCEF business-chain analysis

Use the `ucef` skill for Java business execution excavation. Persist reusable behavior and a Scenario trace assembly together. A deliverable must be readable by a Java developer unfamiliar with the system and must expose field origins, transformations, persistence, external request/response provenance, configuration routes, and explicit gaps.
