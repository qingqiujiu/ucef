# UCEF v0.9 for OpenCode

UCEF builds reusable, evidence-backed Java business execution dossiers. It is project-local by default and has no third-party Python runtime dependencies.

## Install

Copy `.opencode/skills/ucef/` into the root of the Java project OpenCode will analyze.

## Initialize

Initialization creates a durable `.ucef/` analysis workspace, so run it only when the project owner wants persisted analysis artifacts:

```bash
python .opencode/skills/ucef/scripts/init_project.py
```

## Core commands

```bash
python .opencode/skills/ucef/scripts/ucef.py doctor
python .opencode/skills/ucef/scripts/ucef.py reuse --logical-key payment.route
python .opencode/skills/ucef/scripts/ucef.py build-context --scenario .ucef/scenarios/pay.json --work-unit .ucef/work_units/pending/wu.json
python .opencode/skills/ucef/scripts/ucef.py ingest --file .ucef/runs/result.json --work-unit WU-PAY-01
python .opencode/skills/ucef/scripts/ucef.py audit --scenario SCN-PAY --persist
python .opencode/skills/ucef/scripts/ucef.py site
```

Open `.ucef/site/index.html`. The main view is a Scenario dossier with an inline business story, field lineage, persistence, external request/response provenance, and explicit gaps. Reused Fragments appear inline rather than as link-only cards.

## Runtime requirements

- Python 3.10+
- Python standard library only
- OpenCode v2
- IDEA Index MCP recommended for semantic Java retrieval

Production configuration may be queried through the tools available in the user's OpenCode environment. Store relevant effective values as `CONFIG` Evidence; do not persist secrets.
